create view all_session_cln
            (primarykey, visitid, time, channelgrouping, country, city_fix, transactions, v2productcategory, timeonsite,
             pageviews, sessionqualitydim, date, type, productrefundamount, productquantity, productprice,
             productrevenue, productsku, productvariant, currencycode, itemquantity, itemrevenue, tot_txn_revenue,
             transactionid, pagetitle, searchkeyword, pagepathlevel1, ecommerceaction_type, ecommerceaction_step,
             "eCommerceAction_option")
as
SELECT DISTINCT concat(all_sessions.visitid, '-', all_sessions.date, '-', all_sessions."time") AS primarykey,
                all_sessions.visitid,
                all_sessions."time",
                all_sessions.channelgrouping,
                all_sessions.country,
                CASE
                    WHEN all_sessions.city = '(not set)'::text THEN 'N/A'::text
                    WHEN all_sessions.city = 'not available in demo dataset'::text THEN 'N/A'::text
                    ELSE all_sessions.city
                    END                                                                        AS city_fix,
                all_sessions.transactions,
                all_sessions.v2productcategory,
                all_sessions.timeonsite,
                all_sessions.pageviews,
                all_sessions.sessionqualitydim,
                all_sessions.date,
                all_sessions.type,
                all_sessions.productrefundamount,
                all_sessions.productquantity,
                all_sessions.productprice,
                all_sessions.productrevenue,
                all_sessions.productsku,
                all_sessions.productvariant,
                all_sessions.currencycode,
                all_sessions.itemquantity,
                all_sessions.itemrevenue,
                to_number(all_sessions.totaltransactionrevenue, 'FM999,999,999'::text)         AS tot_txn_revenue,
                all_sessions.transactionid,
                all_sessions.pagetitle,
                all_sessions.searchkeyword,
                all_sessions.pagepathlevel1,
                all_sessions.ecommerceaction_type,
                all_sessions.ecommerceaction_step,
                all_sessions."eCommerceAction_option"
FROM all_sessions;

alter table all_session_cln
    owner to postgres;

