create view product_name_compare(mastersku, allsessionsku, productsku, product_name, session_name) as
SELECT m.product_sku   AS mastersku,
       a.productsku    AS allsessionsku,
       p.sku           AS productsku,
       p.name_cln      AS product_name,
       a.v2productname AS session_name
FROM master_sku m
         JOIN all_session_clean a ON m.product_sku = a.productsku
         JOIN products_cln p ON m.product_sku = p.sku;

alter table product_name_compare
    owner to postgres;

