create view products_cln
            (sku, name_cln, orderedquantity, stocklevel, restockingleadtime, sentimentscore, sentimentmagnitude) as
SELECT p.sku,
       TRIM(BOTH FROM p.name) AS name_cln,
       p.orderedquantity,
       p.stocklevel,
       p.restockingleadtime,
       p.sentimentscore,
       p.sentimentmagnitude
FROM products p;

alter table products_cln
    owner to postgres;

