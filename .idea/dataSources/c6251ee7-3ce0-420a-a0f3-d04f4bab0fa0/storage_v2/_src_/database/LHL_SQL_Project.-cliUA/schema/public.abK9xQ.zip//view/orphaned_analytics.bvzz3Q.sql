create view orphaned_analytics
            (all_session_id, visitid, units_sold, unit_price, channelgrouping, socialengagementtype, date, timeonsite,
             pageviews) as
SELECT s.visitid AS all_session_id,
       a.visitid,
       a.units_sold,
       a.unit_price,
       a.channelgrouping,
       a.socialengagementtype,
       a.date,
       a.timeonsite,
       a.pageviews
FROM all_session_clean s
         FULL JOIN analytics_cln a ON s.visitid = a.visitid
WHERE s.visitid IS NULL
  AND a.units_sold IS NOT NULL;

alter table orphaned_analytics
    owner to postgres;

