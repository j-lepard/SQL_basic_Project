create view products_categories
            (sku, name_cln, orderedquantity, stocklevel, restockingleadtime, sentimentscore, categoryl1, categoryl2,
             categoryl3) as
SELECT p.sku,
       TRIM(BOTH FROM p.name) AS name_cln,
       p.orderedquantity,
       p.stocklevel,
       p.restockingleadtime,
       p.sentimentscore,
       c.cat_level1           AS categoryl1,
       c.cat_level2           AS categoryl2,
       c.cat_level3           AS categoryl3
FROM products p
         JOIN productcategories_cln c ON p.sku = c.productsku;

alter table products_categories
    owner to postgres;

