create view analytics_cln
            (visitnumber, visitid, visitstarttime, date, fullvisitorid, userid, channelgrouping, socialengagementtype,
             units_sold, pageviews, timeonsite, bounces, revenue, unit_price, units_sold_num)
as
SELECT a.visitnumber,
       a.visitid,
       a.visitstarttime,
       a.date,
       a.fullvisitorid,
       a.userid,
       a.channelgrouping,
       a.socialengagementtype,
       a.units_sold,
       a.pageviews,
       a.timeonsite,
       a.bounces,
       a.revenue,
       a.unit_price,
       to_number(a.units_sold, '9999'::text) AS units_sold_num
FROM analytics a
WHERE a.units_sold IS NOT NULL
  AND a.revenue IS NOT NULL;

alter table analytics_cln
    owner to postgres;

