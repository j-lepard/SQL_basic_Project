create view productcategories_cln2
            (productsku, v2productcategory, productcategory_fix, catdepth, cat_level1, cat_level2, cat_level3,
             cat_level4) as
SELECT categoryarray.productsku,
       categoryarray.v2productcategory,
       CASE
           WHEN categoryarray.v2productcategory = '${escCatTitle}'::text THEN NULL::text
           WHEN categoryarray.v2productcategory = '(not set)'::text THEN NULL::text
           ELSE categoryarray.v2productcategory
           END                                                               AS productcategory_fix,
       length(categoryarray.v2productcategory) -
       length(replace(categoryarray.v2productcategory, '/'::text, ''::text)) AS catdepth,
       categoryarray.categoriesarray[1]                                      AS cat_level1,
       categoryarray.categoriesarray[2]                                      AS cat_level2,
       categoryarray.categoriesarray[3]                                      AS cat_level3,
       categoryarray.categoriesarray[4]                                      AS cat_level4
FROM (SELECT DISTINCT all_sessions.productsku,
                      all_sessions.v2productcategory,
                      string_to_array(all_sessions.v2productcategory, '/'::text) AS categoriesarray
      FROM all_sessions) categoryarray;

alter table productcategories_cln2
    owner to postgres;

