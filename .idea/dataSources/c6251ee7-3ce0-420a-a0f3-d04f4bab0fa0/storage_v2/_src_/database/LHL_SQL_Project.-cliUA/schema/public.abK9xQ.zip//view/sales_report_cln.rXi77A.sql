create view sales_report_cln
            (productsku, total_ordered, btrim, stocklevel, restockingleadtime, sentimentscore, sentimentmagnitude,
             ratio) as
SELECT sales_report.productsku,
       sales_report.total_ordered,
       TRIM(BOTH FROM sales_report.name) AS btrim,
       sales_report.stocklevel,
       sales_report.restockingleadtime,
       sales_report.sentimentscore,
       sales_report.sentimentmagnitude,
       sales_report.ratio
FROM sales_report;

alter table sales_report_cln
    owner to postgres;

