create view orphaned_products(date, visitid, productsku, v2productname, sku, name_cln) as
SELECT a.date,
       a.visitid,
       a.productsku,
       a.v2productname,
       p.sku,
       p.name_cln
FROM all_sessions a
         FULL JOIN products_cln p ON a.productsku = p.sku
WHERE p.name_cln IS NULL;

alter table orphaned_products
    owner to postgres;

