create view all_session_transactions
            (primarykey, visitid, time, channelgrouping, country, city_fix, transactions, timeonsite, pageviews, date,
             type, productquantity, productprice, productrevenue, productsku, item_quantity, item_revenue,
             tot_txn_revenue, transactionid, pagetitle, pagepathlevel1, ecommerceaction_type, ecommerceaction_step,
             "eCommerceAction_option")
as
SELECT DISTINCT concat(all_session_clean.visitid, '-', all_session_clean.date, '-',
                       all_session_clean."time")                                            AS primarykey,
                all_session_clean.visitid,
                all_session_clean."time",
                all_session_clean.channelgrouping,
                all_session_clean.country,
                CASE
                    WHEN all_session_clean.city = '(not set)'::text THEN 'N/A'::text
                    WHEN all_session_clean.city = 'not available in demo dataset'::text THEN 'N/A'::text
                    ELSE all_session_clean.city
                    END                                                                     AS city_fix,
                all_session_clean.transactions,
                all_session_clean.timeonsite,
                all_session_clean.pageviews,
                all_session_clean.date,
                all_session_clean.type,
                all_session_clean.productquantity::numeric                                  AS productquantity,
                all_session_clean.productprice,
                all_session_clean.productrevenue,
                all_session_clean.productsku,
                to_number(all_session_clean.itemquantity, 'FM999,999,999'::text)            AS item_quantity,
                to_number(all_session_clean.itemrevenue, 'FM999,999,999'::text)             AS item_revenue,
                to_number(all_session_clean.totaltransactionrevenue, 'FM999,999,999'::text) AS tot_txn_revenue,
                all_session_clean.transactionid,
                all_session_clean.pagetitle,
                all_session_clean.pagepathlevel1,
                all_session_clean.ecommerceaction_type,
                all_session_clean.ecommerceaction_step,
                all_session_clean."eCommerceAction_option"
FROM all_session_clean
WHERE all_session_clean.productquantity IS NOT NULL;

alter table all_session_transactions
    owner to postgres;

