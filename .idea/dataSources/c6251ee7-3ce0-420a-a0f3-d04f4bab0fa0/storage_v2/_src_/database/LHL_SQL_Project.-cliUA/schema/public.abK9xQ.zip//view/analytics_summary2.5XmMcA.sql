create view analytics_summary2(visitid, avg_visitprice, max_visitprice, min_visitprice) as
SELECT a.visitid,
       to_char(avg(a.unit_price), 'FM999,999,999'::text) AS avg_visitprice,
       to_char(max(a.unit_price), 'FM999,999,999'::text) AS max_visitprice,
       to_char(min(a.unit_price), 'FM999,999,999'::text) AS min_visitprice
FROM analytics a
GROUP BY a.visitid;

alter table analytics_summary2
    owner to postgres;

