create view master_sku(product_sku) as
SELECT sales_by_sku.product_sku
FROM sales_by_sku
UNION
SELECT sales_report_cln.productsku AS product_sku
FROM sales_report_cln;

alter table master_sku
    owner to postgres;

