create view sales_by_sku_cln(product_sku, total_ordered) as
SELECT sales_by_sku.product_sku,
       sales_by_sku.total_ordered
FROM sales_by_sku;

alter table sales_by_sku_cln
    owner to postgres;

