create view sku_missing_frm_salesbyskurpt(master_list, sales_by_sku, sales_report) as
SELECT m.product_sku AS master_list,
       s.product_sku AS sales_by_sku,
       r.productsku  AS sales_report
FROM master_sku m
         LEFT JOIN sales_by_sku s ON m.product_sku = s.product_sku
         LEFT JOIN sales_report_cln r ON m.product_sku = r.productsku
WHERE r.productsku IS NULL;

alter table sku_missing_frm_salesbyskurpt
    owner to postgres;

